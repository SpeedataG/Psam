package speedatagroup.brxu.com.workdemo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class DeviceControl {
    private BufferedWriter CtrlFile;
    private String gpio="";

    public DeviceControl(String path) throws IOException {
        File DeviceName = new File(path);
        CtrlFile = new BufferedWriter(new FileWriter(DeviceName, false));    //open file
    }
    public DeviceControl(String path,String gpio) throws IOException {
        this.gpio=gpio;
        File DeviceName = new File(path);
        CtrlFile = new BufferedWriter(new FileWriter(DeviceName, false));    //open file
    }

    public void PowerOnDevice()        //poweron psam device
    {
        try {
            CtrlFile.write("-wdout"+gpio+" 1");   //上电IO口调整
            CtrlFile.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void PowerOffDevice()     //poweroff psam device
    {
        try {
            CtrlFile.write("-wdout"+gpio+" 0");
            CtrlFile.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void PsamResetDevice() throws IOException        //reset psam device
    {
        CtrlFile.write("-wdout63 1");
        CtrlFile.flush();
        CtrlFile.write("-wdout63 0");
        CtrlFile.flush();
    }

    public void DeviceClose() throws IOException        //close file
    {
        CtrlFile.close();
    }
}