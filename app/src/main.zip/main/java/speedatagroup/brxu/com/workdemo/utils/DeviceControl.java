package speedatagroup.brxu.com.workdemo.utils;

import android.content.Context;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class DeviceControl {
	private BufferedWriter CtrlFile;
	private Context mContext;

	public DeviceControl(String path, Context context) throws IOException {
		File DeviceName = new File(path);
		mContext = context;
		CtrlFile = new BufferedWriter(new FileWriter(DeviceName, false)); // open
	}

	public void MTGpioOn() {
		try {
			CtrlFile.write("-wdout106 1");
			CtrlFile.flush();
			CtrlFile.write("-wdout63 1");
			CtrlFile.flush();
			Toast.makeText(mContext, "open mtgpio driver success",
					Toast.LENGTH_SHORT).show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void MTGpioOff() {
		try {
			CtrlFile.write("-wdout63 0");
			CtrlFile.flush();
			Toast.makeText(mContext, "close mtgpio driver success",
					Toast.LENGTH_SHORT).show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}