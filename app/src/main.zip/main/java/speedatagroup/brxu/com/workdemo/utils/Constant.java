package speedatagroup.brxu.com.workdemo.utils;

/**
 * Created by Administrator on 2015/9/1.
 */
public class Constant {
        public static String URL="http://192.168.1.24:8080";
//    public static String URL="http://218.247.237.138:8080";
//    public static String URL = "http://192.168.1.202:8080";
    private static String SHAREDPREFERENCESN_NAME = "chengshiyingji";

    //{"id":1,"jobnumber":"1000001","password":"123456","name":"思必拓","mobile":"15910667411",
    // "stationid":1,"email":"service@speedata.cn","gen_time":1440496090000,
    // "last_login_time":1440496090000,"count":0,"levelid":1,"isadmin":0}
    //登陆返回字段
    public static String filed_NAME="name";
    public static String FILED_JOBNUMBER="jobnumber";
    public static String FILED_MOBILE="mobile";
    public static String FILED_STATIONID="stationid";
    public static String FILED_LEVELID="levelid";
    public static String FILED_ID="id";
}
